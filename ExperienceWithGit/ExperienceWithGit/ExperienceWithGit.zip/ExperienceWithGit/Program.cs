﻿using System;

namespace ExperienceWithGit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Today: 12.12.1995");
			Console.WriteLine("Developer in this Project are: ");
            
            //TODO: Write your name here and push all your changes to Github.
            Console.WriteLine("John Doe,");
            Console.WriteLine("Jane Doe,");
            Console.WriteLine(",...");

            Console.ReadLine();
        }
    }
}
